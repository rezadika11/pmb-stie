<?php $__env->startSection('title','Biaya Pendaftaran'); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('backend/vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/toastr/css/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/toastr-custom.css')); ?>">
<style>
    .table-responsive {
        overflow-x: auto !important;
        /* Pastikan ada scroll jika konten lebih lebar */
    }

    #dataTable {
        table-layout: fixed !important;
        /* Menghindari kolom lebar otomatis */
        width: 100% !important;
        /* Pastikan tabel memenuhi lebar kontainer */
    }

    .badge-kip {
        background-color: #28a745;
        color: white;
    }

    .badge-reguler {
        background-color: #007bff;
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-body text-dark">
    <div class="container-fluid">
        <div class="col-sm-6 p-md-0 mb-4">
            <div class="welcome-text">
                <h3><?php echo $__env->yieldContent('title'); ?></h3>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('biaya_prodi.create')); ?>" class="btn btn-sm btn-primary"><i
                                class="bi bi-plus-square"></i> Tambah</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="dataTable" class="display" style="min-width: 100px">
                                <thead>
                                    <tr>
                                        <th width="5%">No.</th>
                                        <th>Gelombang</th>
                                        <th>Program Studi</th>
                                        <th>Jenis Kelas</th>
                                        <th>Pendaftaran</th>
                                        <th>Tri Dharma</th>
                                        <th>Ospek</th>
                                        <th>SPP</th>
                                        <th>SKS</th>
                                        <th>Total</th>
                                        <th>KIP Gratis</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.components.modal-hapus', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendor/toastr/js/toastr.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            scrollX: true,
            drawCallback: function() {
                $('.dataTables_scrollBody').css({
                    'border': 'none',
                    'border-bottom': 'none'
                });
                $('.dataTables_scrollHead').css({
                    'border': 'none',
                    'border-bottom': 'none'
                });
                $('.dataTables_scroll').css('border', 'none');
            },
            ajax: {
                url: "<?php echo e(route('biaya_prodi.datatable')); ?>",
                type: 'GET'
            },
            columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                { data: 'gelombang_info', name: 'gelombang.nama_gelombang' },
                { data: 'program_studi', name: 'prodi.program_studi' },
                { data: 'jenis_kelas', name: 'jenis_kelas' },
                { data: 'biaya_pendaftaran_formatted', name: 'biaya_pendaftaran' },
                { data: 'biaya_tri_dharma_formatted', name: 'biaya_tri_dharma' },
                { data: 'biaya_ospek_formatted', name: 'biaya_ospek' },
                { data: 'biaya_spp_formatted', name: 'biaya_spp' },
                { data: 'biaya_sks_formatted', name: 'biaya_sks' },
                { data: 'total_biaya_formatted', name: 'total_biaya', orderable: false },
                { data: 'kip_status', name: 'gratis_untuk_kip' },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ],
            order: [[ 1, "desc" ]],
        });

            $(document).on('click', '.btn-hapus', function(e) {
                e.preventDefault();
                const id = $(this).data('id');
                const nama = $(this).data('nama');
            
                // Menyimpan ID yang akan dihapus ke dalam tombol di modal
                $('#btnDestroy').data('id', id);
                $('#jenisData').text(nama); // Menampilkan nama data di modal
                $('#konfirmasiHapusModal').modal('show');
            });
        
            $('#btnDestroy').click(function (e) {
                e.preventDefault();
                const id = $(this).data('id'); // Mengambil ID yang disimpan
            
                $.ajax({
                    url: `<?php echo e(route('biaya_prodi.destroy', '')); ?>/${id}`,
                    type: 'DELETE',
                    headers: {
                    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                },
                dataType: 'json',
                success: function(response) {
                    if(response.status === 'success') {
                        toastr.success(response.message);
                    // Reload tabel atau hapus baris yang dihapus dari tabel
                    $('#dataTable').DataTable().ajax.reload();
                    } else {
                        toastr.error(response.message);
                    }
                        $('#konfirmasiHapusModal').modal('hide'); // Menyembunyikan modal setelah penghapusan
                },
                error: function(xhr) {
                    toastr.error('Gagal menghapus data.');
                    $('#konfirmasiHapusModal').modal('hide'); // Menyembunyikan modal jika terjadi error
                }
            });
        });

        // Toastr notifications
        <?php if(session('success')): ?>
            toastr.success('<?php echo e(session('success')); ?>');
        <?php endif; ?>

        <?php if(session('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>');
        <?php endif; ?>
    });

    // Function untuk delete data
    // function deleteData(id, url) {
    //     if (confirm('Yakin ingin menghapus data ini?')) {
    //         $.ajaxSetup({
    //             headers: {
    //                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //             }
    //         });

    //         $.ajax({
    //             url: url,
    //             type: 'DELETE',
    //             success: function(response) {
    //                 $('#dataTable').DataTable().ajax.reload();
    //                 toastr.success('Data berhasil dihapus!');
    //             },
    //             error: function(xhr) {
    //                 toastr.error('Terjadi kesalahan saat menghapus data!');
    //             }
    //         });
    //     }
    // }

    // Add CSRF meta tag
    // $('head').append('<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">');
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/biaya_prodi/index.blade.php ENDPATH**/ ?>