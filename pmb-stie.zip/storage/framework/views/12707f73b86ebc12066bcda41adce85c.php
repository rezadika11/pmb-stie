<div class="step active" data-step="1">
    <div class="card-header">
        Identitas Pribadi
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama" value="<?php echo e($user); ?>"  readonly>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>NIK</label>
                    <input type="number" name="nik" class="form-control"
                    data-original-nik="<?php echo e($mhs->nik ?? ''); ?>" 
                    value="<?php echo e($mhs->nik ?? ''); ?>" placeholder="Masukan NIK">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" class="form-control" name="tempat_lahir" value="<?php echo e(old('tempat_lahir',$mhs->tempat_lahir ?? '')); ?>"  placeholder="Masukan Tempat Lahir">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="text" id="date" class="form-control" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir',$mhs->tanggal_lahir ?? '')); ?>" autocomplete="off">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" >
                        <option value="" disabled selected>Pilih Jenis Kelamin</option>
                        <?php $__currentLoopData = $jk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('jenis_kelamin',$mhs->jenis_kelamin ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Agama</label>
                    <select class="form-control" id="agama" name="agama" >
                        <option value="" disabled selected>Pilih Agama</option>
                        <?php $__currentLoopData = $agm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('agama',$mhs->agama ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Status Perkawinan</label>
                    <select name="kawin" id="kawin" class="form-control" >
                        <option value="" disabled selected>Pilih Status Perkawinan</option>
                        <?php $__currentLoopData = $kawin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('kawin',$mhs->status_kawin ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Kewarganegaraan</label>
                    <select name="kewarganegaraan" id="kewarganegaraan" class="form-control" >
                        <option value="" disabled selected>Pilih Kewarganegaraan</option>
                        <?php $__currentLoopData = $warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('kewarganegaraan',$mhs->kewarganegaraan ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Asal Sekolah (SMA/MA, SMK)</label>
                    <input type="text" class="form-control" name="asal_sekolah" value="<?php echo e(old('asal_sekolah',$mhs->asal_sekolah ?? '')); ?>" placeholder="Masukan Asal Sekolah" >
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Asal PTS (untuk mahasiswa transfer)</label>
                    <input type="text" class="form-control" name="pts_transfer" value="<?php echo e(old('pts_transfer',$mhs->pts_transfer ?? '')); ?>" placeholder="Masukan Asal PTS (untuk mahasiswa transfer)">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Alamat (Jl, RT, RW)</label>
                    <input type="text" class="form-control" name="alamat" value="<?php echo e(old('alamat',$mhs->alamat ?? '')); ?>"  placeholder="Masukan Alamat Jl, RT, RW">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Provinsi</label>
                    <select name="provinsi" id="provinsi" class="select2 form-control" >
                        <option selected disabled>Pilih Provinsi</option>
                        <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->id); ?>" 
                            <?php echo e(old('provinsi', $mhs->id_prov ?? '') == $val->id ? 'selected' : ''); ?>>
                            <?php echo e($val->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Kabupaten</label>
                    <select name="kabupaten" id="kabupaten" class="select2 form-control" >
                        <option selected disabled>Pilih Kabupaten</option>
                    
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Kecamatan</label>
                    <select name="kecamatan" id="kecamatan" class="select2 form-control" >
                        <option selected disabled>Pilih Kecamatan</option>
                    
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Desa</label>
                    <select name="desa" id="desa" class="select2 form-control" >
                        <option selected disabled>Pilih Desa</option>
                    
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Kode Pos</label>
                    <input type="number" class="form-control" name="kode_pos" value="<?php echo e(old('kode_pos',$mhs->kode_pos ?? '')); ?>"  placeholder="Masukan Kode Pos">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">No. Telepon/HP</label>
                    <input type="number" class="form-control" name="no_hp" value="<?php echo e(old('no_hp',$mhs->no_hp ?? '')); ?>" placeholder="Masukan No HP">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Pekerjaan (bila sudah bekerja)</label>
                    <input type="text" class="form-control" name="pekerjaan" value="<?php echo e(old('pekerjaan',$mhs->pekerjaan ?? '')); ?>"  placeholder="Masukan Pekerjaan">
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/mhs/step/data-pribadi.blade.php ENDPATH**/ ?>