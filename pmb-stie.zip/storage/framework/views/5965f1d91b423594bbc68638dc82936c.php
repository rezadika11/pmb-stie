
<?php $__env->startSection('title','Tambah Users'); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/toastr/css/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
            <div class="col-sm-6 p-md-0 mb-4">
                <div class="welcome-text">
                    <h3><?php echo $__env->yieldContent('title'); ?></h3>
                </div>
            </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="basic-form">
                            <form id="formSimpan">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label text-dark">Nama Lengkap<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="text" id="name" name="name" class="form-control" placeholder="Masukan Nama Lengkap" autofocus>
                                        <div class="name-error text-danger"></div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label text-dark">Email<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="email" id="email" name="email" class="form-control" placeholder="Masukan Email" autofocus>
                                        <div class="email-error text-danger"></div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label text-dark">Hak Akses<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <select name="roles" id="roles" class="form-control">
                                            <option value="" selected disabled>Pilih Hak Akses</option>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"
                                                <?php echo e(old('roles') == $key ? 'selected' : ''); ?>>
                                                <?php echo e($val); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="roles-error text-danger"></div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label text-dark">Password<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="password" id="password" name="password" class="form-control" placeholder="Masukan Password" autofocus>
                                        <div class="password-error text-danger"></div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label text-dark">Ulangi Password<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="password" id="password1" name="password1" class="form-control" placeholder="Masukan Ulangi Password" autofocus>
                                        <div class="password1-error text-danger"></div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary"><i class="bi bi-floppy"></i> Simpan</button>
                                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-light">Kembali <i class="bi bi-arrow-right"></i></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/vendor/toastr/js/toastr.min.js')); ?>"></script>
<script>
$(document).ready(() => {
    $('#formSimpan').submit(function (e) {
        e.preventDefault();

        let formData = {
            name : $('#name').val(),
            email : $('#email').val(),
            roles : $('#roles').val(),
            password : $('#password').val(),
            password1 : $('#password1').val(),
        }

        $.ajax({
            type: "POST",
            url: "<?php echo e(route('users.store')); ?>",
            data: formData,
            dataType: "json",
            headers: {
                'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
            },
            beforeSend: function () {
                // Bersihkan error sebelumnya
                $.each($('.text-danger'), function () {
                    $(this).text('');
                });
                // $('button[type="submit"]').html('<i class="spinner-border spinner-border-sm"></i> Menyimpan...').attr('disabled', true);
            },
            success: function (res) {
                // toastr.success('Users baru berhasil disimpan.');
                window.location.href = res.redirect;
            },
            error: function(xhr) {
                    if (xhr.responseJSON && xhr.responseJSON.errors) {
                        let errors = xhr.responseJSON.errors;

                        // Bersihkan error sebelumnya
                        $('.name-error, .email-error, .roles-error,.password-error,.password1-error').text('');

                        $.each(errors, function(key, value) {
                            $('.' + key + '-error').text(value[0]);
                        });
                    } else {
                        console.error("Unexpected error response:", xhr);
                        alert("An unexpected error occurred. Please try again.");
                    }
                }
            // complete: function () {
            //     $('button[type="submit"]').html('<i class="bi bi-floppy"></i> Simpan').attr('disabled', false);
            // }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/users/create.blade.php ENDPATH**/ ?>