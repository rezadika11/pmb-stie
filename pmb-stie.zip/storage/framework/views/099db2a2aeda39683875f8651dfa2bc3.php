<div class="step" data-step="2">
    <div class="card-header">
        Data Orang Tua
    </div>
    <div class="card-body">
        
        <input type="hidden" name="id_ortu" value="<?php echo e($ortu->id ?? ''); ?>">
        <input type="hidden" name="id_mahasiswa" value="<?php echo e($mhs->id ?? ''); ?>">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Nama Ayah</label>
                    <input type="text" name="nama_ayah" id="nama_ayah" class="form-control" value="<?php echo e(old('nama_ayah',$ortu->nama_ayah ?? '')); ?>" placeholder="Masukan Nama Ayah">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Nama Ibu</label>
                    <input type="text" name="nama_ibu" id="nama_ibu" class="form-control" value="<?php echo e(old('nama_ibu',$ortu->nama_ibu ?? '')); ?>" placeholder="Masukan Nama Ibu">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tempat Lahir Ayah</label>
                    <input type="text" class="form-control" name="tempat_lahir_ayah" id="tempat_lahir_ayah" value="<?php echo e(old('tempat_lahir_ayah',$ortu->tempat_lahir_ayah ?? '')); ?>" placeholder="Masukan Tempat Lahir Ayah">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tempat Lahir Ibu</label>
                    <input type="text" class="form-control" name="tempat_lahir_ibu" id="tempat_lahir_ibu" value="<?php echo e(old('tempat_lahir_ibu',$ortu->tempat_lahir_ibu ?? '')); ?>" placeholder="Masukan Tempat Lahir Ibu">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tanggal Lahir Ayah</label>
                    <input type="text" id="date_ayah" class="form-control" name="tanggal_lahir_ayah" value="<?php echo e(old('tanggal_lahir_ayah',$ortu->tanggal_lahir_ayah ?? '')); ?>" placeholder="Masukan Tanggal Lahir Ayah" autocomplete="off">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Tanggal Lahir Ibu</label>
                    <input type="text" id="date_ibu" class="form-control" name="tanggal_lahir_ibu"  value="<?php echo e(old('tanggal_lahir_ibu',$ortu->tanggal_lahir_ibu ?? '')); ?>" placeholder="Masukan Tanggal Lahir Ibu" autocomplete="off">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>NIK Ayah</label>
                    <input type="number" 
                    class="form-control" 
                    name="nik_ayah" 
                    data-original-nik="<?php echo e($ortu->nik_ayah ?? ''); ?>" 
                    value="<?php echo e(old('nik_ayah', $ortu->nik_ayah ?? '')); ?>" 
                    placeholder="Masukan NIK Ayah">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>NIK Ibu</label>
                   <input type="number" 
                    class="form-control" 
                    name="nik_ibu" 
                    data-original-nik="<?php echo e($ortu->nik_ibu ?? ''); ?>" 
                    value="<?php echo e(old('nik_ibu', $ortu->nik_ibu ?? '')); ?>" 
                    placeholder="Masukan NIK Ibu">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Pendidikan Ayah</label>
                    <select name="pendidikan_ayah" id="pendidikan_ayah" class="form-control">
                        <option disabled selected>Pilih Pendidikan Ayah</option>
                        <?php $__currentLoopData = $didik_ayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('pendidikan_ayah', $ortu->pendidikan_ayah ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Pendidikan Ibu</label>
                    <select name="pendidikan_ibu" id="pendidikan_ibu" class="form-control">
                        <option disabled selected>Pilih Pendidikan Ibu</option>
                        <?php $__currentLoopData = $didik_ibu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('pendidikan_ibu', $ortu->pendidikan_ibu ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Pekerjaan Ayah</label>
                    <select name="pekerjaan_ayah" id="pekerjaan_ayah" class="form-control">
                        <option disabled selected>Pilih Pekerjaan Ayah</option>
                        <?php $__currentLoopData = $kerja_ayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('pekerjaan_ayah',$ortu->pekerjaan_ayah ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Pekerjaan Ibu</label>
                    <select name="pekerjaan_ibu" id="pekerjaan_ibu" class="form-control">
                        <option disabled selected>Pilih Pekerjaan Ibu</option>
                        <?php $__currentLoopData = $kerja_ibu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('pekerjaan_ibu',$ortu->pekerjaan_ibu ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Penghasilan Ayah</label>
                    <select name="penghasilan_ayah" id="penghasilan_ayah" class="form-control">
                        <option disabled selected>Pilih Penghasilan Ayah</option>
                        <?php $__currentLoopData = $hasil_ayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('penghasilan_ayah',$ortu->penghasilan_ayah ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Penghasilan Ibu</label>
                    <select name="penghasilan_ibu" id="penghasilan_ibu" class="form-control">
                        <option disabled selected>Pilih Penghasilan Ibu</option>
                        <?php $__currentLoopData = $hasil_ibu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('penghasilan_ibu',$ortu->penghasilan_ibu ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>No HP Ayah</label>
                    <input type="number" class="form-control" name="no_hp_ayah" id="no_hp_ayah" value="<?php echo e(old('no_hp_ayah',$ortu->no_hp_ayah ?? '')); ?>" placeholder="Masukan No HP Ayah">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>No HP Ibu</label>
                    <input type="number" class="form-control" name="no_hp_ibu" id="no_hp_ibu" value="<?php echo e(old('no_hp_ibu',$ortu->no_hp_ibu ?? '')); ?>" placeholder="Masukan No HP Ibu">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Alamat Orang Tua</label>
                    <input type="text" class="form-control" name="alamat_ortu" id="alamat_ortu" value="<?php echo e(old('no_hp_ibu',$ortu->alamat_ortu ?? '')); ?>"  placeholder="Masukan Alamat Jl, RT, RW">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Provinsi</label>
                    <select name="provinsi_ortu" id="provinsi_ortu" class="select2 form-control" >
                        <option selected disabled>Pilih Provinsi</option>
                        <?php $__currentLoopData = $provinsiOrtuList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->id); ?>" 
                            <?php echo e(old('provinsi_ortu', $ortu->id_prov ?? '') == $val->id ? 'selected' : ''); ?>>
                            <?php echo e($val->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Kabupaten</label>
                    <select name="kabupaten_ortu" id="kabupaten_ortu" class="select2 form-control">
                        <option selected disabled>Pilih Kabupaten</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Kecamatan</label>
                    <select name="kecamatan_ortu" id="kecamatan_ortu" class="select2 form-control" >
                        <option selected disabled>Pilih Kecamatan</option>
                    
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="">Desa</label>
                    <select name="desa_ortu" id="desa_ortu" class="select2 form-control" >
                        <option selected disabled>Pilih Desa</option>
                    
                    </select>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/mhs/step/data-orang-tua.blade.php ENDPATH**/ ?>