<?php $__env->startSection('title','Edit Biaya Pendaftaran'); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/toastr/css/toastr.min.css')); ?>">
<style>
    .form-group label {
        font-weight: 600;
    }

    .currency-input {
        position: relative;
    }

    .currency-input::before {
        content: 'Rp';
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
        z-index: 1;
    }

    .currency-input input {
        padding-left: 35px;
    }
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-body text-dark">
    <div class="container-fluid">
        <div class="col-sm-6 p-md-0 mb-4">
            <div class="welcome-text">
                <h3><?php echo $__env->yieldContent('title'); ?></h3>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('biaya_prodi.update', $biayaProdi->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="id_gelombang">Gelombang <span class="text-danger">*</span></label>
                                        <select name="id_gelombang" id="id_gelombang"
                                            class="form-control <?php $__errorArgs = ['id_gelombang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Pilih Gelombang</option>
                                            <?php $__currentLoopData = $gelombangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gelombang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gelombang->id); ?>" <?php echo e((old('id_gelombang', $biayaProdi->
                                                id_gelombang) == $gelombang->id) ? 'selected' : ''); ?>>
                                                <?php echo e($gelombang->nama_gelombang); ?> - <?php echo e($gelombang->tahunAkademik ?
                                                substr($gelombang->tahunAkademik->kode, 0, 4) . '/' .
                                                substr($gelombang->tahunAkademik->kode, 4, 4) : 'N/A'); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_gelombang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="jenis_kelas">Jenis Kelas <span class="text-danger">*</span></label>
                                        <select name="jenis_kelas" id="jenis_kelas"
                                            class="form-control <?php $__errorArgs = ['jenis_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Pilih Jenis Kelas</option>
                                            <?php $__currentLoopData = $jenis_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kode); ?>" <?php echo e((old('jenis_kelas', $biayaProdi->jenis_kelas) == $kode) ? 'selected' : ''); ?>>
                                                <?php echo e($nama); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['jenis_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="program_studi">Program Studi <span
                                                class="text-danger">*</span></label>
                                        <select name="program_studi" id="program_studi"
                                            class="form-control <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">Pilih Program Studi</option>
                                            <?php $__currentLoopData = $prodi_studi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kode); ?>" <?php echo e((old('program_studi', $biayaProdi->
                                                program_studi) == $kode) ? 'selected' : ''); ?>>
                                                <?php echo e($nama); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="biaya_pendaftaran">Biaya Pendaftaran <span
                                                class="text-danger">*</span></label>
                                        <div class="currency-input">
                                            <input type="number" name="biaya_pendaftaran" id="biaya_pendaftaran"
                                                class="form-control <?php $__errorArgs = ['biaya_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('biaya_pendaftaran', $biayaProdi->biaya_pendaftaran)); ?>"
                                                min="0" required>
                                        </div>
                                        <?php $__errorArgs = ['biaya_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="biaya_tri_dharma">Biaya Tri Dharma <span
                                                class="text-danger">*</span></label>
                                        <div class="currency-input">
                                            <input type="number" name="biaya_tri_dharma" id="biaya_tri_dharma"
                                                class="form-control <?php $__errorArgs = ['biaya_tri_dharma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('biaya_tri_dharma', $biayaProdi->biaya_tri_dharma)); ?>"
                                                min="0" required>
                                        </div>
                                        <?php $__errorArgs = ['biaya_tri_dharma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="biaya_ospek">Biaya Ospek <span class="text-danger">*</span></label>
                                        <div class="currency-input">
                                            <input type="number" name="biaya_ospek" id="biaya_ospek"
                                                class="form-control <?php $__errorArgs = ['biaya_ospek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('biaya_ospek', $biayaProdi->biaya_ospek)); ?>" min="0"
                                                required>
                                        </div>
                                        <?php $__errorArgs = ['biaya_ospek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="biaya_spp">Biaya SPP <span class="text-danger">*</span></label>
                                        <div class="currency-input">
                                            <input type="number" name="biaya_spp" id="biaya_spp"
                                                class="form-control <?php $__errorArgs = ['biaya_spp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('biaya_spp', $biayaProdi->biaya_spp)); ?>" min="0" required>
                                        </div>
                                        <?php $__errorArgs = ['biaya_spp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6" id="biaya_sks_container">
                                    <div class="form-group">
                                        <label for="biaya_sks">Biaya SKS <span class="text-danger" id="biaya_sks_required">*</span></label>
                                        <div class="currency-input">
                                            <input type="number" name="biaya_sks" id="biaya_sks"
                                                class="form-control <?php $__errorArgs = ['biaya_sks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('biaya_sks', $biayaProdi->biaya_sks)); ?>" min="0" required>
                                        </div>
                                        <?php $__errorArgs = ['biaya_sks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <small class="text-muted" id="biaya_sks_note" style="display: none;">Untuk kelas sore, biaya SKS tidak diperlukan karena menggunakan sistem SPP tetap</small>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <div class="custom-control custom-checkbox">
                                            <input type="hidden" name="gratis_untuk_kip" value="0">
                                            <input type="checkbox" class="custom-control-input" id="gratis_untuk_kip"
                                                name="gratis_untuk_kip" value="1" <?php echo e(old('gratis_untuk_kip',
                                                $biayaProdi->gratis_untuk_kip) ? 'checked' :
                                            ''); ?>>
                                            <label class="custom-control-label" for="gratis_untuk_kip">
                                                Gratis untuk mahasiswa KIP
                                            </label>
                                        </div>
                                        <small class="text-muted">Centang jika mahasiswa KIP tidak dikenakan
                                            biaya</small>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-floppy"></i> Update
                                </button>
                                <a href="<?php echo e(route('biaya_prodi.index')); ?>" class="btn btn-light ml-2">
                                    Kembali <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card ">
                    <div class="card-header">
                        <h5 class="card-title">Informasi Saat Ini</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm" style="color: #313030">
                            <tr>
                                <td><strong>Gelombang:</strong></td>
                                <td><?php echo e($biayaProdi->gelombang->nama_gelombang); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Jenis Kelas:</strong></td>
                                <td>
                                    <?php if($biayaProdi->jenis_kelas === 'sore'): ?>
                                    <span class="badge badge-warning">Sore</span>
                                    <?php else: ?>
                                    <span class="badge badge-primary">Pagi</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Program Studi:</strong></td>
                                <td><?php echo e($biayaProdi->nama_program_studi); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Total Biaya:</strong></td>
                                <td>Rp <?php echo e(number_format($biayaProdi->total_biaya, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <td><strong>KIP Gratis:</strong></td>
                                <td>
                                    <?php if($biayaProdi->gratis_untuk_kip): ?>
                                    <span class="badge badge-success">Ya</span>
                                    <?php else: ?>
                                    <span class="badge badge-secondary">Tidak</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>

                        <div class="alert alert-warning mt-3">
                            <h6><i class="bi bi-exclamation-triangle"></i> Perhatian:</h6>
                            <p class="mb-0 text-dark">Perubahan biaya akan mempengaruhi semua mahasiswa yang mendaftar
                                di
                                gelombang dan program studi ini.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/vendor/toastr/js/toastr.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        // Format number input
        $('input[type="number"]').on('input', function() {
            let value = $(this).val();
            if (value < 0) {
                $(this).val(0);
            }
        });

        // Handle jenis kelas change untuk biaya SKS
        $('#jenis_kelas').on('change', function() {
            const jenisKelas = $(this).val();
            const biayaSksInput = $('#biaya_sks');
            const biayaSksRequired = $('#biaya_sks_required');
            const biayaSksNote = $('#biaya_sks_note');
            
            if (jenisKelas === 'sore') {
                // Untuk kelas sore, disable field biaya SKS dan set ke 0
                biayaSksInput.prop('readonly', true).removeAttr('required').val(0);
                biayaSksRequired.hide();
                biayaSksNote.show();
            } else {
                // Untuk kelas pagi, enable field biaya SKS dan wajib diisi
                biayaSksInput.prop('readonly', false).attr('required', true);
                biayaSksRequired.show();
                biayaSksNote.hide();
                if (biayaSksInput.val() == 0) {
                    biayaSksInput.val('');
                }
            }
        });

        // Trigger change event on page load
        $('#jenis_kelas').trigger('change');

        // Before form submission, ensure biaya_sks has a value for 'sore' class
        $('form').on('submit', function() {
            const jenisKelas = $('#jenis_kelas').val();
            const biayaSksInput = $('#biaya_sks');
            
            if (jenisKelas === 'sore' && (biayaSksInput.val() === '' || biayaSksInput.val() === null)) {
                biayaSksInput.val(0);
            }
        });

        // Toastr notifications
        <?php if(session('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>');
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/biaya_prodi/edit.blade.php ENDPATH**/ ?>