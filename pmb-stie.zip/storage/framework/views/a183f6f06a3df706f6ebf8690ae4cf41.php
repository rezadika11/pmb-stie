<div class="footer">
    <div class="copyright">
        <p>Copyright © STIE TAMBARA &amp; Developed by <a href="#" target="_blank">erdekasoft</a> <?php echo e(date('Y')); ?></p>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>