
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <?php if(Auth::user()->roles == 'superadmin'): ?>
                        <h4>Selamat Datang <?php echo e(Auth::user()->name); ?></h4>
                    <?php elseif(Auth::user()->roles == 'admin'): ?>
                        <h4>Selamat Datang <?php echo e(Auth::user()->name); ?></h4>
                    <?php elseif(Auth::user()->roles == 'mhs'): ?>
                    <h4>Selamat Datang <?php echo e(Auth::user()->name); ?>,</h4>
                    <?php
                        $tahunAkademik = date('Y') . '/' . (date('Y') + 1);
                    ?>
                    <span class="text-dark">Penerimaan Mahasiswa Baru STIE Tamansiswa Banjarnegara <?php echo e($tahunAkademik); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if(Auth::user()->roles == 'superadmin'): ?>
            <?php echo $__env->make('backend.components.dashboard-superadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif(Auth::user()->roles == 'admin'): ?>
            <?php echo $__env->make('backend.components.dashboard-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif(Auth::user()->roles == 'mhs'): ?>
            <?php echo $__env->make('backend.components.dashboard-mhs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>