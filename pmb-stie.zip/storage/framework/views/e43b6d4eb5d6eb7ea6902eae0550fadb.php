<div class="step" data-step="3">
    <div class="card-header">
        Program Studi
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <?php if(isset($mhs->id_program_studi)): ?>
                    <input type="hidden" name="id_prodi" value="<?php echo e($mhs->id_program_studi); ?>">
                    <?php endif; ?>
                    <input type="hidden" name="id_mahasiswa" value="<?php echo e($mhs->id ?? ''); ?>">
                    <label>Jenis Pendaftaran</label>
                    <select class="form-control" name="jenis_pendaftaran" id="jenis_pendaftaran">
                        <option disabled selected>Pilih Jenis Pendaftaran</option>
                        <?php $__currentLoopData = $jenis_daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('jenis_pendaftaran', $prodi->jenis_pendaftaran ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Program Studi</label>
                    <select class="form-control" name="program_studi" id="program_studi">
                        <option disabled selected>Pilih Prodi Studi</option>
                        <?php $__currentLoopData = $prodi_studi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('program_studi', $prodi->program_studi ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Jenis Kelas</label>
                    <select class="form-control" name="jenis_kelas" id="jenis_kelas">
                      <option value="">Pilih Jenis Kelas</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('jenis_kelas', $prodi->jenis_kelas ?? '')==$key ? 'selected' : ''); ?>>
                            <?php echo e($val); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/mhs/step/data-prodi.blade.php ENDPATH**/ ?>