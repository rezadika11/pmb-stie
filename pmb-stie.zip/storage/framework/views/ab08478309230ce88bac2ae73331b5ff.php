<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?> - PMB STIE Tamansiswa Banjarnegara </title>
    <!-- Favicon icon -->
    <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('backend/img/logo-stie.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/font/bootstrap-icons.min.css')); ?>">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">
    <style>
        .content-body {
            min-height: 94vh !important;
            display: flex !important;
            flex-direction: column !important;
        }

        .container-fluid {
            flex-grow: 1 !important;
        }
    </style>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">
        <?php echo $__env->make('layouts.backend.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('layouts.backend.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.backend.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <!-- Required vendors -->

    <script src="<?php echo e(asset('backend/js/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/quixnav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/custom.min.js')); ?>"></script>
    
    <?php echo $__env->yieldPushContent('js'); ?>

    <!-- Circle progress -->

</body>

</html><?php /**PATH C:\laragon\www\pmb-stie\resources\views/layouts/backend/main.blade.php ENDPATH**/ ?>