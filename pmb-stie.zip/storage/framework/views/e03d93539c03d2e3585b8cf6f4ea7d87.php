<div class="nav-header">
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-logo" id="logo-container">
        <img class="logo-abbr" src="<?php echo e(asset('backend/img/logo-stie.png')); ?>" >
        <img class="logo-compact" src="<?php echo e(asset('backend/img/pmb.png')); ?>" alt="">
        <img class="brand-title" src="<?php echo e(asset('backend/img/pmb.png')); ?>" alt="">
    </a>
     
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>
<div class="header">
    <div class="header-content">
        <nav class="navbar navbar-expand">
            <div class="collapse navbar-collapse justify-content-between">
                <div class="header-left">
                    
                </div>

                <ul class="navbar-nav header-right">
                    <li class="nav-item dropdown header-profile">
                        <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                            <i class="bi bi-person-circle"></i>
                            <span style="font-size: 15px"><?php echo e(Auth::user()->name); ?></span> 
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <?php
                                $user = Auth::user();
                            ?>
                            <?php if($user->roles == 'superadmin'): ?>
                            <a href="<?php echo e(route('superadmin.profile')); ?>" class="dropdown-item">
                                <i class="bi bi-person"></i>
                                <span class="ml-2">Profil </span>
                            </a>
                            <?php elseif($user->roles == 'admin'): ?>
                            <a href="<?php echo e(route('admin.profile')); ?>" class="dropdown-item">
                                <i class="bi bi-person"></i>
                                <span class="ml-2">Profil </span>
                            </a>
                            <?php elseif($user->roles == 'mhs'): ?>
                            <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">
                                <i class="bi bi-person"></i>
                                <span class="ml-2">Profil </span>
                            </a>
                            <?php endif; ?>
                         
                            <hr>
                            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item">
                                <i class="bi bi-box-arrow-right"></i>
                                <span class="ml-2">Logout</span>
                            </a>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/layouts/backend/navbar.blade.php ENDPATH**/ ?>