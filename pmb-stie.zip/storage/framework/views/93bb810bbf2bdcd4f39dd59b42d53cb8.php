<div class="modal fade" id="gelombangModal" tabindex="-1" role="dialog" aria-labelledby="gelombangModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="gelombangModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="gelombangForm">
                <?php echo csrf_field(); ?>
                <div class="modal-body text-dark">
                    
                    <?php if($gelombang): ?>
                    <div class="alert alert-danger text-dark" role="alert">
                        Tanggal gelombang harus di antara
                        <strong><?php echo e($gelombang->tanggal_mulai); ?></strong>
                        dan
                        <strong><?php echo e($gelombang->tanggal_selesai); ?></strong>
                    </div>
                    <?php endif; ?>


                    <input type="hidden" name="id_tahun_akademik" id="id_tahun_akademik"
                        value="<?php echo e($tahunAjaran->id ?? ''); ?>">
                    <input type="hidden" name="id" id="gelombang_id">
                    <div class="form-group">
                        <label for="nama_gelombang">Nama Gelombang</label>
                        <input type="text" name="nama_gelombang" id="nama_gelombang" class="form-control"
                            placeholder="Contoh: Gelombang 1">
                        <span class="text-danger text-sm error-text nama_gelombang_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_mulai">Tanggal Mulai</label>
                        <input type="text" name="tanggal_mulai" id="tglMulai" class="form-control">
                        <span class="text-danger text-sm error-text tanggal_mulai_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_selesai">Tanggal Selesai</label>
                        <input type="text" name="tanggal_selesai" id="tglSelesai" class="form-control">
                        <span class="text-danger text-sm error-text tanggal_selesai_error"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Batal</button>
                    <button type="submit" id="btnSimpan" class="btn btn-sm btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/backend/gelombang/modal-gelombang.blade.php ENDPATH**/ ?>