<header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="<?php echo e(route('home')); ?>" class="logo d-flex align-items-center me-auto">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="<?php echo e(asset('backend/img/logo-stie.png')); ?>" height="100%" >
        
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('/') ? 'active' : ''); ?>">Beranda<br></a></li>
          <?php
            $pendaftaran = DB::table('pendaftaran')->get();
          ?>
           <li class="dropdown"><a href="#"><span>Pendaftaran</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
            <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('pendaftaran',$item->slug)); ?>"><?php echo e($item->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>
          <?php
          $registrasi = DB::table('registrasi')->get();
          ?>
         <li class="dropdown"><a href=""><span>Registrasi</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
          <ul>
          <?php $__currentLoopData = $registrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('registrasi',$item->slug)); ?>"><?php echo e($item->name); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </li>
          <li><a href="<?php echo e(route('brosur')); ?>">Brosur</a></li>
          <li><a href="<?php echo e(route('kontak')); ?>">Kontak</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
      <?php if(!Auth::check()): ?>
      <a class="btn btn-getstarted btn-daftar" href="<?php echo e(route('register')); ?>">
        Daftar
        <i class="bi bi-person-plus-fill ms-2"></i>
      </a>
      <a class="btn btn-getstarted btn-login" href="<?php echo e(route('login')); ?>">
          Login
          <i class="bi bi-box-arrow-in-right ms-2"></i>
      </a>
      
      <?php endif; ?>
    </div>
 
</header><?php /**PATH C:\laragon\www\pmb-stie\resources\views/layouts/frontend/navbar.blade.php ENDPATH**/ ?>