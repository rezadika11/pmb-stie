<div class="quixnav">
    <div class="quixnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li class="<?php echo e(request()->routeIs('dashboard') ? 'mm-active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"
                    aria-expanded="false"><i class="bi bi-grid"></i><span class="nav-text">Dashboard</span></a></li>

            
            <?php if(Auth::user()->roles == 'superadmin'): ?>
            <li
                class="<?php echo e(request()->routeIs('pendaftaran*') || request()->routeIs('registrasi*') || request()->routeIs('brosur*') || request()->routeIs('kontak*') ? 'mm-active' : ''); ?>">
                <a class="has-arrow" href="javascript:void()"
                    aria-expanded="<?php echo e(request()->routeIs('pendaftaran*') || request()->routeIs('registrasi*') || request()->routeIs('brosur*') || request()->routeIs('kontak*') ? 'true' : 'false'); ?>"><i
                        class="bi bi-sliders"></i><span class="nav-text">Halaman</span></a>
                <ul aria-expanded="<?php echo e(request()->routeIs('pendaftaran*') || request()->routeIs('registrasi*') || request()->routeIs('brosur*') || request()->routeIs('kontak*') ? 'true' : 'false'); ?>"
                    class="mm-collapse <?php echo e(request()->routeIs('pendaftaran*') || request()->routeIs('registrasi*') || request()->routeIs('brosur*') || request()->routeIs('kontak*') ? 'mm-show' : ''); ?>">
                    <li class="<?php echo e(request()->routeIs('pendaftaran*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('pendaftaran.index')); ?>">
                            <span class="nav-text">Pendaftaran</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('registrasi*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('registrasi.index')); ?>">
                            <span class="nav-text">Registrasi</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('brosur*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('brosur.index')); ?>">
                            <span class="nav-text">Brosur</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('kontak*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('kontak.index')); ?>">
                            <span class="nav-text">Kontak</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li
                class="<?php echo e(request()->routeIs('banner*') || request()->routeIs('tentang*') ||  request()->routeIs('count*') || request()->routeIs('testimoni*') ? 'mm-active' : ''); ?>">
                <a class="has-arrow" href="javascript:void()"
                    aria-expanded="<?php echo e(request()->routeIs('banner*') || request()->routeIs('tentang*') || request()->routeIs('count*') || request()->routeIs('testimoni*')  ? 'true' : 'false'); ?>"><i
                        class="bi bi-house-gear"></i></i><span class="nav-text">Beranda</span></a>
                <ul aria-expanded="<?php echo e(request()->routeIs('banner*') || request()->routeIs('tentang*') || request()->routeIs('count*') || request()->routeIs('testimoni*') ? 'true' : 'false'); ?>"
                    class="mm-collapse <?php echo e(request()->routeIs('banner*') || request()->routeIs('tentang*') ||  request()->routeIs('count*') || request()->routeIs('testimoni*')   ? 'mm-show' : ''); ?>">
                    <li class="<?php echo e(request()->routeIs('banner*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('banner.index')); ?>">
                            <span class="nav-text">Banner</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('tentang*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('tentang.index')); ?>">
                            <span class="nav-text">Tentang</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('count*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('count.index')); ?>">
                            <span class="nav-text">Jumlah</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('testimoni*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('testimoni.index')); ?>">
                            <span class="nav-text">Testimoni</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="<?php echo e(request()->routeIs(['tahun_akademin.*','gelombang.*']) ? 'mm-active' : ''); ?>"><a
                    class="has-arrow" href="javascript:void()"
                    aria-expanded="<?php echo e(request()->routeIs(['tahun_akademin.*','gelombang.*'])  ? 'true' : 'false'); ?>"><i
                        class="bi bi-calendar"></i></i><span class="nav-text">Pengaturan Pendaftaran</span></a>
                <ul aria-expanded="<?php echo e(request()->routeIs(['tahun_akademin.*','gelombang.*','biaya_prodi.*'])  ? 'true' : 'false'); ?>"
                    class="mm-collapse <?php echo e(request()->routeIs(['tahun_akademin.*','gelombang.*','biaya_prodi.*'])   ? 'mm-show' : ''); ?>">
                    <li class="<?php echo e(request()->routeIs('tahun_akademik.*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('tahun_akademik.index')); ?>">
                            <span class="nav-text">Tahun Akademik</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('gelombang.*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('gelombang.index')); ?>">
                            <span class="nav-text">Gelombang</span>
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('biaya_prodi.*') ? 'mm-active' : ''); ?>">
                        <a href="<?php echo e(route('biaya_prodi.index')); ?>">
                            <span class="nav-text">Biaya Pendaftaran</span>
                        </a>
                    </li>
                </ul>
            </li>

            

            

            
            <li class="nav-label first">Setting</li>
            <li class="<?php echo e(request()->routeIs('users*') ? 'mm-active' : ''); ?>"><a href="<?php echo e(route('users.index')); ?>"
                    aria-expanded="false"><i class="bi bi-people"></i><span class="nav-text">User</span></a></li>
            <?php elseif(Auth::user()->roles == 'admin'): ?>
            <li class="<?php echo e(request()->routeIs('pmb*') ? 'mm-active' : ''); ?>"><a href="<?php echo e(route('pmb.index')); ?>"
                    aria-expanded="false"><i class="bi bi-file-earmark-text"></i><span class="nav-text">PMB</span></a>
            </li>

            
            <li class="<?php echo e(request()->routeIs('laporan*') ? 'mm-active' : ''); ?>"><a href="<?php echo e(route('laporan.index')); ?>"
                    aria-expanded="false"><i class="bi bi-archive"></i><span class="nav-text">Laporan</span></a></li>
            <?php elseif(Auth::user()->roles == 'mhs'): ?>
            <li class="<?php echo e(request()->routeIs('formulir*') ? 'mm-active' : ''); ?>"><a href="<?php echo e(route('formulir.index')); ?>"
                    aria-expanded="false"><i class="bi bi-file-earmark-text"></i><span
                        class="nav-text">Formulir</span></a></li>
            <?php endif; ?>

            
        </ul>
    </div>
</div><?php /**PATH C:\laragon\www\pmb-stie\resources\views/layouts/backend/sidebar.blade.php ENDPATH**/ ?>